<?php
    class Order
    {
        private $name;
        private $tel;
        private $execution;
        private $other;

        function __construct($execution, $name, $other, $tel)
        {
            $this->execution = $execution;
            $this->name = $name;
            $this->other = $other;
            $this->tel = $tel;
        }

        public function setExecution($execution)
        {
            $this->execution = $execution;
        }

        public function getExecution()
        {
            return $this->execution;
        }

        public function setName($name)
        {
            $this->name = $name;
        }

        public function getName()
        {
            return $this->name;
        }

        public function setOther($other)
        {
            $this->other = $other;
        }

        public function getOther()
        {
            return $this->other;
        }

        public function setTel($tel)
        {
            $this->tel = $tel;
        }

        public function getTel()
        {
            return $this->tel;
        }
    }
?>