<?php
    class upFile
    {
        private $name;
        private $tmpName;
        private $path;
        private $type;
        private $fileName;

        public function getName()
        {
            return $this->name;
        }
        public function getPath()
        {
            return $this->path;
        }
        public function getTmpName()
        {
            return $this->tmpName;
        }
        public function getType()
        {
            return $this->type[0];
        }

        public function getFileName()
        {
            return $this->fileName;
        }

        public function setName($name)
        {
            $this->name = $name;
        }
        public function setPath($path)
        {
            $this->path = $path;
        }

        public function upload()
        {
            $fileName = rand(0,300000).$this->type[0];
            while(true)
            {
                if(!file_exists($this->path.$fileName))
                    break;
                $fileName = rand(0,300000).$this->type[0];
            }
            $this->fileName = $fileName;
            if(!move_uploaded_file($this->tmpName,$this->path.$fileName))
                return -1;
            $name = $this->name;
            $type = $this->type[0];
            mysql_query("INSERT INTO `file` (`realName`, `name`, `path`) VALUES ('$name', '$fileName', '$type')");
            return 0;
        }

        public function __toString()
        {
            return $this->getFileName();
        }

        public function __construct($name, $path, $tmpName)
        {
            preg_match('/\.[a-z0-9]*$/i',$name,$this->type);
            $this->name = $name;
            $this->tmpName = $tmpName;
            $this->path = $path;
            $this->upload();
        }
    }

?>