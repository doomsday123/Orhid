<?php
    include ("user.php");
    include ("upFile.php");
    include ("dress.php");
    include ("order.php");
    include ("sewing.php");
?>