<?php
    class Sewing extends Order
    {
        private $file;
        private $dress;

        function __construct($id)
        {
            $array = mysql_return("SELECT `name`, `tel`, `date`, `file`, `other`, `dress` FROM `sewing` WHERE `id` = '$id'");
            $this->setOther($array["other"]);
            $this->setFile($array["file"]);
            $this->setExecution($array["date"]);
            $this->setName($array["name"]);
            $this->setTel($array["tel"]);
            $this->setDress($array["dress"]);
        }

        public function setFile($file)
        {
            $this->file = $file;
        }

        public function getFile()
        {
            return $this->file;
        }

        public function setDress($dress)
        {
            $this->dress = $dress;
        }

        public function getDress()
        {
            return $this->dress;
        }

        public static function add($name, $tel, $execution, $file, $dress, $other, $user)
        {
            mysql_query("INSERT INTO `sewing`(`name`, `tel`, `date`, `file`, `other`, `user`, `dress`)
            VALUES ('$name','$tel','$execution','$file','$other','$user','$dress')");
        }
    }
?>