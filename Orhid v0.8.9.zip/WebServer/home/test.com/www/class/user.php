<?php

class User
{
    private $id;
    private $name;
    private $access;

    public function getAccess()
    {
        return $this->access;
    }
    public function getId()
    {
        return $this->id;
    }
    public function getName()
    {
        return $this->name;
    }

    public function setAccess($access)
    {
        $this->access = $access;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function setName($name)
    {
        $this->name = $name;
    }

    public static function userExists($text,$parameter)
    {

        switch($parameter)
        {
            case 'id':
                if(mysql_return("SELECT `login` FROM `users` WHERE `id` = '$text'"))
                    return true;
                else
                    return false;
            break;
            case 'login':
                if(mysql_return("SELECT `id` FROM `users` WHERE `login` = '$text'"))
                    return true;
                else
                    return false;
            break;
            case 'ssid':
                $userArray = mysql_return("SELECT `login` FROM `users` WHERE `ssid` = '$text'");
                if($userArray)
                    return $userArray["login"];
                else
                    return false;
                break;
            default:
                return "Error!";
            break;
        }
    }
    public static function login($login,$passowrd)
    {
        $userArray = mysql_return("SELECT `password` FROM `users` WHERE `login` = '$login'");
        if(!$userArray)
            return false;
        if(!(md5($passowrd) == $userArray["password"]))
            return false;
        $ssid = session_id();
        mysql_query("UPDATE `users` SET `ssid`='$ssid' WHERE `login` = '$login'");
        return true;
    }

    public function __construct($login)
    {
        $userArray = mysql_return("SELECT `id`, `name`, `access` FROM `users` WHERE `login` = '$login'");
        $this->id = $userArray["id"];
        $this->access = $userArray["access"];
        $this->name = $userArray["name"];
    }
}
?>