<?php

class Dress
{
    public function __construct($id)
    {
        $this->id = $id;
        $array = mysql_return("SELECT `front`, `rear`, `sn`, `price`, `available`, `other`, `user` FROM `dress` WHERE `id` = '$id'");
        if(!$array)
            $this->error = 1;
        $this->available = $array["available"];
        $this->front = $array["front"];
        $this->other = $array["other"];
        $this->price = $array["price"];
        $this->rear = $array["rear"];
        $this->serialNumber = $array["sn"];
        $this->user = $array["user"];
        $this->error = 0;
    }

    public function getError()
    {
        return $this->error;
    }

    public function getAvailable()
    {
        return $this->available;
    }

    public function getFront()
    {
        return $this->front;
    }

    public function getOther()
    {
        return $this->other;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function getRear()
    {
        return $this->rear;
    }

    public function getSerialNumber()
    {
        return $this->serialNumber;
    }

    public function getUser()
    {
        return $this->user;
    }

    public static function dressExist($sn)
    {
        if (mysql_return("SELECT `id` FROM `dress` WHERE `sn` = '$sn'"))
            return true;
        else
            return false;
    }

    public function setAvailable($available)
    {
        $this->available = $available;
    }

    public function setOther($other)
    {
        $this->other = $other;
    }

    public function setFront($front)
    {
        $this->front = $front;
    }

    public function setPrice($price)
    {
        $this->price = $price;
    }

    public function setRear($rear)
    {
        $this->rear = $rear;
    }

    public function setSerialNumber($serialNumber)
    {
        $this->serialNumber = $serialNumber;
    }

    public function update()
    {
        $q = "UPDATE `dress` SET `front`='".$this->getFront()."',`rear`='".$this->getRear()."',`sn`='".$this->getSerialNumber()."',`price`='".$this->getPrice()."',`available`='".$this->getAvailable()."',`other`='".$this->getOther()."' WHERE `id` = '".$this->id."'";
        mysql_query($q);
        return $this->price;
    }


    private $serialNumber;
    private $price;
    private $available;
    private $other;
    private $front;
    private $rear;
    private $user;
    private $error;
    private $id;
}