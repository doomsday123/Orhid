<?php
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

if($user->getAccess() != "Admin" && $user->getAccess() != "Boss")
    exit();
$login = $_GET["login"];
if($user::userExists($login,"login"))
echo "true";
else
echo "false";
?>
