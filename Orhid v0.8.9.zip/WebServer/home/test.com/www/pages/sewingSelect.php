<?php
$sewing = new Sewing($_GET["id"]);
if ($sewing->getFile() == '') {
    $sn = $sewing->getDress();
    $array = mysql_return("SELECT `id` FROM `dress` WHERE `sn` = '$sn'");
    $id = $array["id"];
    $ex = "<a href='/?page=selectDress&id=" . $id . "'>Просмотреть платье.</a>";
}
else
{
    $ex = "<a href='".$sewing->getFile()."'>Скачать файл.</a>";
}

?>

<div class="img-rounded content">
    <div class="container">
        <div class="offset2 span6" style="margin-top: 10px">
            <table style="width: 452px">
                <tr>
                    <td style="text-align: right">Имя: </td>
                    <td><?=$sewing->getName()?></td>
                </tr>
                <tr>
                    <td style="text-align: right">Телефон: </td>
                    <td><?=$sewing->getTel()?></td>
                </tr>
                <tr>
                    <td style="text-align: right">Сдать до: </td>
                    <td><?=$sewing->getExecution()?></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center">Дополнительно</td>
                </tr>
                <tr>
                    <td colspan="2" style="max-width: 450px; word-wrap: break-word"><?=$ex . "<br>" . $sewing->getOther()?></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <div id="submit" class="btn btn-success" style="width: 93%">Выполнено<i
                                class="icon-ok"></i></td>
                </tr>
            </table>
        </div>
    </div>
</div>


<script>
    var id = <?=$_GET["id"]?>;
    $("#submit").click(function () {
        $.ajax({
            type: "GET",
            url: "/pages/sewingDell.php",
            data: "id="+id,
            success: function(msg){
                window.location.href = "/?page=showSewing";
            }
        });
    });
</script>