<?php
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

if($user->getAccess() != "Admin" && $user->getAccess() != "Boss")
    exit();
$id = $_GET["id"];
$newPass = md5($_GET["newpass"]);
if(strlen($_GET["newpass"]) < 5)
    exit("Пароль должен состоять как минимум из 5-ти символов.");
mysql_query("UPDATE `users` SET `password`='$newPass' WHERE `id` = '$id'");
echo "true";
?>