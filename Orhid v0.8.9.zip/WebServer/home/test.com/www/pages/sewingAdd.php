<?php
    if(isset($_POST["name"]))
    {
        if($_POST["flag"] == 0)
        {
            $f = new upFile($_FILES["file"]["name"],"files/",$_FILES["file"]["tmp_name"]);
            $dress = NULL;
            $file = "/files/".$f;
        }
        else
        {
            $file = NULL;
            $dress = $_POST["sn"];
        }
        Sewing::add($_POST["name"],$_POST["tel"],$_POST["date"],$file,$dress,$_POST["other"],$user->getId());
        echo'
        <script>
            window.location.href = "/?page=showSewing";
        </script>
        ';
    }
?>
<div class="img-rounded content">
    <form id="form" action="/?page=newSewing" method="post" enctype="multipart/form-data">
        <div class="container">
            <div class="offset2 span6" style="margin-top: 10px">
                <table>
                    <tr>
                        <td>Ф.И.О.</td>
                        <td>
                            <div id="name" class="control-group" style="margin-bottom: 0px">
                                <input type="text" name="name">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Телефон</td>
                        <td>
                            <div id="tel" class="control-group" style="margin-bottom: 0px">
                                <input type="tel" name="tel" pattern="\(\d\d\d\) ?\d\d\d-\d\d-\d\d"
                                       placeholder="(###) ###-##-##">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Дата выполнения</td>
                        <td>
                            <div id="date" class="control-group" style="margin-bottom: 0px">
                                <input type="date" name="date">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td id="extraName">Файл</td>
                        <td>
                            <input id="extraFile" name="file" type="file" class="btn btn-mini"
                                   style="width: 183px">
                            <input id="extraSN" name="sn" type="text" style="width: 190px">
                            <i id="switch" class="icon-repeat"></i>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center">Дополнительно</td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="controls">
                                <textarea name="other" style="width: 96%"></textarea>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div id="submit" class="btn btn-success" style="width: 93%" onclick="submitBTN()">Добавить<i
                                    class="icon-plus"></i></div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <input type="hidden" name="flag" id="flag">
    </form>
</div>

<script>
    var flag = 0;
    $("#extraSN").hide();
    $("#switch").click(function () {
        if (flag == 0) {
            $("#extraName").html("С.Н. платья");
            $("#extraSN").show();
            $("#extraFile").hide();
            flag = 1;
        }
        else {
            $("#extraName").html("Файл");
            $("#extraFile").show();
            $("#extraSN").hide();
            flag = 0;
        }
    });

    $("[name='tel']").blur(function ()
    {
        if($("[name='tel']").val().length == 10)
        {
            var t = $("[name='tel']").val();
            $("[name='tel']").val('('+t[0]+t[1]+t[2]+') '+t[3]+t[4]+t[5]+'-'+t[6]+t[7]+'-'+t[8]+t[9]);
        }
    });

    function submitBTN() {
        var error = false;
        if ($("[name='name']").val().length == 0) {
            $("#name").removeClass("success");
            $("#name").addClass("error");
            error = true;
        }
        else
        {
            $("#name").removeClass("error");
            $("#name").addClass("success");
        }
        if ($("[name='date']").val().length == 0) {
            $("#date").removeClass("success");
            $("#date").addClass("error");
            error = true;
        }
        else
        {
            $("#date").removeClass("error");
            $("#date").addClass("success");
        }
        if ($("[name='tel']").val().length == 15)
        {
            $("#tel").removeClass("error");
            $("#tel").addClass("success");
        }
        else
        {
            error = true;
            $("#tel").removeClass("success");
            $("#tel").addClass("error");
        }

        if(error == false)
        {
            $("#flag").val(flag);
            $("#form").submit();
        }
    }


</script>


