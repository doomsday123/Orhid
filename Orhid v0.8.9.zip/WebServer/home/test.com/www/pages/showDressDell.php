<?php
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

$id = $_GET["id"];
$array = mysql_return("SELECT `front`, `rear` FROM `dress` WHERE `id` = '$id'");
if(!$array)
    exit("false");

$front = $array["front"];
$rear = $array["rear"];
mysql_query("DELETE FROM `dress` WHERE `id` = '$id'");
mysql_query("DELETE FROM `file` WHERE `name` = '$front'");
mysql_query("DELETE FROM `file` WHERE `name` = '$rear'");
unlink("../img/".$front);
unlink("../img/".$rear);
exit("true");
?>