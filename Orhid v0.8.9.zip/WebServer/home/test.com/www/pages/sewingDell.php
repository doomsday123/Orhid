<?php
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

$sew = new Sewing($_GET["id"]);

$id = $_GET["id"];
if($sew->getFile())
{
    $file = $sew->getFile();
    $file = strrev($file);
    $fileName = '';
    for($i = 0; $file[$i]!= '/'; $i++)
    {
        $fileName = $file[$i].$fileName;
    }
    unlink("../files/".$fileName);
}

mysql_query("DELETE FROM `sewing` WHERE `id` = '$id'");
mysql_query("DELETE FROM `file` WHERE `name` = '$fileName'");
?>