<?php

$id = $_GET["id"];
$dress = new Dress($id);
if($dress->getError() == 1)
    exit("false");
?>
<link rel="stylesheet" type="text/css" href="/css/cloudzoom.css" />
<script type="text/javascript" src="/js/cloudzoom.js"></script>
<script type="text/javascript">
    CloudZoom.quickStart();
</script>

<div class="img-rounded content">
    <div class="row">
        <div style="margin-left:6%" class="show">
            <div class="dressSelect span3">
                <img class = "cloudzoom dressSelectIMG" src = "<?="/img/".$dress->getFront()?>"
                     data-cloudzoom = "zoomImage: '<?="/img/".$dress->getRear()?>'" onmouseover="hidetrial()"/>
            </div>
            <div style="float: left; margin-top: 10px; margin-left: 5%">
                <table style="max-width: 450px">
                    <tr>
                        <td style="text-align: right; width: 230px">Серйный номер:</td>
                        <td id="sn"><?=$dress->getSerialNumber()?></td>
                    </tr>
                    <tr>
                        <td style="text-align: right">В наличии:</td>
                        <td id="av"><?=$dress->getAvailable()?></td>
                    </tr>
                    <tr>
                        <td style="text-align: right">Цена:</td>
                        <td id="co"><?=$dress->getPrice()?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center; width: 450px">Дополнительно</td>
                    </tr>
                    <tr>
                        <td colspan="2" id="ot" style="max-width: 450px; word-wrap: break-word"><?=$dress->getOther()?></td>
                    </tr>
                    <tr style="text-align: center">
                        <td colspan="2"><button class="btn btn-danger" id="<?=$id?>">Удалить</button>
                        <button class="btn btn btn-warning" id="<?=$id?>" onclick="edit()">Изменить</button>
                        <button class="btn btn-success" id="<?=$id?>" onclick="save()">Сохранить</button></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    var id = <?=$id?>;
    var start = $("#sn").text();
    $(".btn-success").hide();
    $(document).ready(function() {
        $(".btn-danger").click(function () {
            var id = $(".btn-danger").attr("id");
            $.ajax({
                type: "GET",
                url: "/pages/showDressDell.php",
                data: "id="+id,
                success: function(msg){
                    if(msg == "true")
                    {
                        $("body").html('<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/?page=showDress">');
                    }
                }
            });
        });
    });
    function hidetrial()
    {
        setTimeout(function() {
            $(".cloudzoom-blank").children().not(".cloudzoom-lens").hide();
        }, 4);
    }
    function edit()
    {
        start = $("#sn").text();
        $("#ot").html("<textarea class='ot' style='width: 436px'>"+$("#ot").text()+"</textarea>");
        $("#sn").html("<input class='input-small sn' value='"+$("#sn").text()+"'>");
        $("#av").html("<input class='input-small av' value='"+$("#av").text()+"'>");
        $("#co").html("<input class='input-small co' value='"+$("#co").text()+"'>");
        $(".btn-warning").hide();
        $(".btn-success").show();
    }

    function save()
    {
        var sn = $(".sn").val();
        $.ajax({
            type: "GET",
            url: "/pages/dressExist.php",
            data: "sn="+sn,
            success: function(msg){
                if(start == $(".sn").val())
                    msg = "false";
                if(msg == "true")
                {
                    alert(msg+" "+start+" |"+$(".sn").val());
                    $("#sn").addClass("control-group error");
                }
                else
                {
                    $.ajax({
                        type: "GET",
                        url: "/pages/showDressEdit.php",
                        data: "id="+id+"&av="+$(".av").val()+"&ot="+$(".ot").val()+"&sn="+$(".sn").val()+"&co="+$(".co").val(),
                        success: function(msg){

                        }
                    });
                    $("#ot").html($(".ot").val());
                    $("#sn").html($(".sn").val());
                    $("#av").html($(".av").val());
                    $("#co").html($(".co").val());
                    $(".btn-warning").show();
                    $(".btn-success").hide();
                }
            }
        });

    }


</script>