<?php
if(!isset($user))
    exit("false");
if(isset($_POST["sn"]))
{
    $sn = (int)$_POST["sn"];
    $price = (int)$_POST["price"];
    $available = (int)$_POST["available"];
    $other = $_POST["other"];

    if(dress::dressExist($sn) || strlen($sn) == 0)
        exit("false");
    if(strlen($price) == 0)
        exit("false");
    if(strlen($available) == 0)
        exit("false");
    $front = new upFile($_FILES["front"]["name"],"img/",$_FILES["front"]["tmp_name"]);
    $rear = new upFile($_FILES["rear"]["name"],"img/",$_FILES["rear"]["tmp_name"]);

    $id = $user->getId();
    mysql_query("INSERT INTO `dress`(`front`, `rear`, `sn`, `price`, `available`, `other`, `user`)
    VALUES ('$front','$rear','$sn','$price','$available','$other','$id')");
    echo '
    <script>
    $(document).ready(function () {
        $(".content").css("border-color","green");
        setTimeout(function(){
            $(".content").css("border-color","#ccc");
        },3000);
    });
    </script>
    ';
}
?>

<form id="form" action="/?page=newDress" method="post" enctype="multipart/form-data">
<div class="img-rounded content">
    <div class="container">
        <div class="offset2 span6" style="margin-top: 10px">
            <table style="text-align: right">
                <tr>
                    <td>Серийный номер:</td>
                    <td>
                        <div id="sn" class="control-group">
                            <div class="controls">
                                <input name="sn" type="text" id="inputError" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Цена:</td>
                    <td>
                        <div id="price" class="control-group">
                            <div class="controls">
                                <input name="price" type="text" id="inputError" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>В наличии:</td>
                    <td>
                        <div id="available" class="control-group">
                            <div class="controls">
                                <input name="available" type="text" id="inputError" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Уменшенная копия:</td>
                    <td>
                        <div id="front" class="control-group">
                            <div class="controls">
                                <input name="front" type="file" id="inputError" class="btn btn-mini" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Полномаштабная:</td>
                    <td>
                        <div id="rear" class="control-group">
                            <div class="controls">
                                <input name="rear" type="file" id="inputError" class="btn btn-mini" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center">Дополнительная информация</td>
                </tr>
                <tr>
                    <td colspan="2">
                        <div id="other" class="control-group">
                            <div class="controls">
                                <textarea name="other" class="form-search" style="width: 100%"></textarea>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <div id="submit" class="btn btn-success" style="width: 100%">Добавить<i class="icon-plus"></i></div>
                    </td>
                </tr>
            </table>

        </div>
    </div>
</div>
</form>

<script>
    var point;
    $("#submit").click(function () {
        point = 0;
        function snExist(sn){
            return $.ajax({
                type: "GET",
                url: "/pages/dressExist.php",
                data: "sn="+sn,
                success: function(msg){
                    if(msg == "true")
                    {
                        $("#sn").removeClass("success");
                        $("#sn").addClass("error");
                        point--;
                    }
                    else
                    {
                        if(point == 0)
                            $("form").submit();
                    }
                }
            });
        }

        var reg = /[^0-9]+/i;
        if($("[name='sn']").val().length == 0)
        {
            $("#sn").removeClass("success");
            $("#sn").addClass("error");
            point--;
        }
        else
        {
            $("#sn").removeClass("error");
            $("#sn").addClass("success");
        }
        if($("[name='price']").val().length == 0 || reg.test($("[name='price']").val()))
        {
            $("#price").removeClass("success");
            $("#price").addClass("error");
            point--;
        }
        else
        {
            $("#price").removeClass("error");
            $("#price").addClass("success");
        }
        if($("[name='available']").val().length == 0 || reg.test($("[name='available']").val()))
        {
            $("#available").removeClass("success");
            $("#available").addClass("error");
            point--;
        }
        else
        {
            $("#available").removeClass("error");
            $("#available").addClass("success");
        }

        snExist($("[name='sn']").val());
    });
</script>
