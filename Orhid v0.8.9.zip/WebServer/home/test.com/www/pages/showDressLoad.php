<?php
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

$n = (int)$_GET['n'];
$querySTR = "SELECT `id`, `front` FROM  `dress` LIMIT ".($n).",".($n+3);
$query = mysql_query($querySTR);
$array = mysql_fetch_array($query);

while($array)
{
    echo '<a href="/?page=selectDress&id='.$array["id"].'"><img id='.$array["id"].' src="/img/'.$array["front"].'" class="dressIMG span3"></a>';
    $array = mysql_fetch_array($query);
}
?>