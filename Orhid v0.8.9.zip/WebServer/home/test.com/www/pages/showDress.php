<?php
$query = mysql_query("SELECT `id` , `front` FROM  `dress` LIMIT 0,9");
$array = mysql_fetch_array($query);
?>
<script>
    var n = 9;
    $(document).ready(function () {
        $(".dressIMG").hover(function (){
            $(this).css("box-shadow","0 0 18px rgba(0, 0, 0, 0.70)");
        }, function (){
            $(this).css("box-shadow","0 0 20px rgba(0, 0, 0, 2)");
        });
    });

    var flag = 0;
    $(window).scroll(function(){
        if ( ($(document).height() - $(window).height() <= $(window).scrollTop() + 400) && flag == 0) {
            flag = 1;
            $.ajax({
                type: "GET",
                url: "/pages/showDressLoad.php",
                data: "n="+n,
                success: function(msg){
                    $(".show").append(msg);
                    if(msg.length > 0)
                        n+=3;
                    setTimeout(function() {
                        flag = 0;
                    },2000);
                }
            });
        }
    });
</script>
<div class="img-rounded content">
    <div class="row">
        <div style="margin-left:6%" class="show">
            <?
                while($array)
                {
                    echo '<a href="/?page=selectDress&id='.$array["id"].'"><img id='.$array["id"].' src="/img/'.$array["front"].'" class="dressIMG span3"></a>';
                    $array = mysql_fetch_array($query);
                }

            ?>
        </div>
    </div>
</div>