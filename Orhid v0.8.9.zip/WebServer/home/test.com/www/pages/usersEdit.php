<?
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

if($user->getAccess() != "Admin" && $user->getAccess() != "Boss")
    exit();

$val = $_GET["val"];
$id = $_GET["id"];
switch ($_GET["type"])
{
    case l:
        $type = "login";
        if(mysql_return("SELECT `id` FROM `users` WHERE `login` = '$val'"))
            exit("false");
    break;
    case n:
        $type = "name";
    break;
    case a:
        $type = "access";
    break;
    default:
        $type = "ssid";
    break;
}


$query = 'UPDATE `users` SET '.$type.'="'.$val.'" WHERE id = '.$id;
mysql_query($query);
echo "true";

