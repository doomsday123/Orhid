<?php
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

$dress = new Dress($_GET["id"]);
$dress->setAvailable($_GET["av"]);
$dress->setOther($_GET["ot"]);
$dress->setPrice($_GET["co"]);
$dress->setSerialNumber($_GET["sn"]);
echo $dress->update();


?>