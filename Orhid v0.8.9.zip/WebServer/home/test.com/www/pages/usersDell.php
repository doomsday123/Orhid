<?
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

if($user->getAccess() != "Admin" && $user->getAccess() != "Boss")
    exit();

$id = $_GET["id"];
mysql_query("DELETE FROM `users` WHERE `id` = '$id'");
?>