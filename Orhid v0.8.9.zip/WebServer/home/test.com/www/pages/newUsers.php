<?php
if($user->getAccess() != "Admin" && $user->getAccess() != "Boss")
    exit('<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/">');

?>
<div class="img-rounded content">
    <div class="container">
        <div class="offset2 span6" style="margin-top: 10px">
            <table style="text-align: right">
                <tr>
                    <td>Имя:</td>
                    <td>
                        <div id="name" class="control-group">
                            <div class="controls">
                                <input name="name" type="text" id="inputError" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Логин:</td>
                    <td>
                        <div id="login" class="control-group">
                            <div class="controls">
                                <input name="login" type="text" id="inputError" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Пароль:</td>
                    <td>
                        <div id="password" class="control-group">
                            <div class="controls">
                                <input name="password" type="password" id="inputError" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Повтор пароля:</td>
                    <td>
                        <div id="repassword" class="control-group">
                            <div class="controls">
                                <input name="repassword" type="password" id="inputError" style="margin-bottom: -5px; width: 210px">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Права доступа:</td>
                    <td>
                        <select name="access" class="input-large" style="width: 224px; margin-bottom: 0px;">
                            <option>Admin</option>
                            <option>Boss</option>
                            <option>User</option>
                        </select>
                    </td>
                </tr>
            </table>
            <div id="submit" class="btn btn-success" style="width: 334px">Зерегистрировать <i class="icon-plus"></i></div>
        </div>
    </div>
</div>

<script>
    var point = 0;
    function loginExist(login)
    {
        var ret = false;
        return $.ajax({
            type: "GET",
            url: "/pages/newUserLoginExist.php",
            data: "login="+login,
            success: function(msg){
                if(msg == "true")
                {
                    $("#login").removeClass("success");
                    $("#login").addClass("error");
                    point--;
                }
            }
        });
    }

    $("#submit").click(function (){
        point = 0;
        if($("[name='name']").val().length < 3)
        {
            $("#name").removeClass("success");
            $("#name").addClass("error");
            point--;
        }
        else
        {
            $("#name").removeClass("error");
            $("#name").addClass("success");
        }
        if($("[name='login']").val().length < 4)
        {
            $("#login").removeClass("success");
            $("#login").addClass("error");
            point--;
        }
        else
        {
            $("#login").removeClass("error");
            $("#login").addClass("success");
            loginExist($("[name='login']").val());
        }
        if($("[name='password']").val() != $("[name='repassword']").val())
        {
            $("#password").removeClass("success").addClass("error");
            $("#repassword").removeClass("success").addClass("error");
            point--;
        }
        else
        {
            $("#password").removeClass("error").addClass("success");
            $("#repassword").removeClass("error").addClass("success");
        }
        if($("[name='password']").val().length < 5)
        {
            $("#password").removeClass("success").addClass("error");
            $("#repassword").removeClass("success").removeClass("error");
            point--;
        }
        if(point == 0)
        {
            $.ajax({
                type: "GET",
                url: "/pages/newUserAddUser.php",
                data: "name="+$("[name='name']").val()+"&login="+$("[name='login']").val()+"&password="+$("[name='password']").val()+"&access="+$("[name='access']").val(),
                success: function(msg){
                    if(msg == "true")
                        $("body").html('<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/?page=users">');
                }
            });
        }
    });
</script>
