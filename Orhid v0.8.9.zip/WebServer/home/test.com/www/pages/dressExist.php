<?php
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

$sn = $_GET["sn"];
if(Dress::dressExist($sn))
    exit("true");
else
    exit("false");