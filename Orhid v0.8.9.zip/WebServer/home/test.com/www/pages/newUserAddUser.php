<?php
include ('../function/function.php');
include ('../class/classes.php');
connectDataBase('orchid');
include ('../function/checkLogin.php');

$name = $_GET["name"];
if(strlen($name) < 3)
    exit("false");
$login = $_GET["login"];
if(strlen($login) < 4)
    exit("false");
if($user::userExists($login,"login"))
    exit("false");
$password = $_GET["password"];
if(strlen($password) < 5)
    exit("false");
$password = md5($password);
$access = $_GET["access"];
if( ($access != "Admin") && ($access != "Boss") && ($access != "User") )
    exit("false");

mysql_query("INSERT INTO `users`(`login`, `name`, `access`, `password`) VALUES ('$login','$name','$access','$password')");
exit("true");