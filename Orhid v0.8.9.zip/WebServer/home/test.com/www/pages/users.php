<?php
if($user->getAccess() != "Admin" && $user->getAccess() != "Boss")
    exit('<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/">');
$query = mysql_query("SELECT `id`, `login`, `name`, `access` FROM `users` WHERE 1");
$array = mysql_fetch_array($query);

while($array)
{
    echo('<div id='.$array["id"].' class="img-rounded userList">');
    echo('<span id='.$array["id"].' class="edit" type="login">'.$array["login"].'</span>');
    echo("(");
    echo('<span id='.$array["id"].' class="edit" type="name">'.$array["name"].'</span>');
    echo(") [");
    echo('<span id='.$array["id"].' class="edit" type="access">'.$array["access"].'</span>');
    echo("]");
    echo('<div id='.$array["id"].' class="btn dell btn-danger" style="float: right"><i class="icon-trash"></i></div>');
    echo('<div id='.$array["id"].' class="btn repass btn-warning" style="float: right"><i class="icon-lock"></i></div>');
    echo('</div>');
    $array = mysql_fetch_array($query);
}
?>

<script>
    var editable = false;
    var oldValue = "";
    var object;
    var id;
    var type;
    var idRepas;
    $(".dell").click(function() {
        if(confirm("Удалить пользователя?"))
        {
            $('#'+this.id).hide(500);
            $.ajax({
                type: "GET",
                url: "/pages/usersDell.php",
                data: "id="+this.id
            });
        }
    });
    $(".edit").click(function(target) {
        if(editable == false)
        {
            editable = true;
            oldValue = this.innerText;
            object = this;
            id = this.id;
            type = target.currentTarget.outerHTML.charAt(32);
            this.innerHTML = '<input class="input-small" id="editable" value="'+this.innerText+'">';
        }
        else
        {
            object.innerHTML = oldValue;
            editable = false;
        }
    });
    $(".repass").click(function (){
        $("#repass").modal();
        idRepas = id = this.id;
    });
    $(document).keydown(function (key) {
        if(key.which == 13)
        if(editable == true)
        {
            $.ajax({
                type: "GET",
                url: "/pages/usersEdit.php",
                data: "id="+id+"&type="+type+"&val="+$("#editable").val(),
                success: function (msg){
                    if(msg != 'true')
                    {
                        $('#modal').modal();
                        object.innerHTML = oldValue;
                    }
                    else
                        object.innerHTML = $("#editable").val();
                }
            });
            editable = false;
        }
    });
</script>

<div id="modal" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3>Ошибка</h3>
    </div>
    <div class="modal-body">
        <p>Этот логин уже используется!</p>
    </div>
</div>

<div id="repass" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3>Изменение пароля</h3>
    </div>
    <div class="modal-body">
        <p><div style="float: left">Новый пароль: <input type="password" id="newpass"></div><div class="btn submit btn-success" title="Изменение пароля" data-content="Минимальная дрина пароля 5-ть символов!" id="confirmpass" style="float: left"><i class="icon-check"></i></div></p>
    </div>
    <script>
        $("#confirmpass").click(function (){
            $.ajax({
                type: "GET",
                url: "/pages/usersRepass.php",
                data: "newpass="+$("#newpass").val()+"&id="+idRepas,
                success: function (msg){
                    if(msg != 'true')
                    {
                        $("#bedpass").modal();
                    }
                    else
                    {
                        $("#repass").modal('hide');
                    }
                }
            });
        });
    </script>
</div>

<div id="bedpass" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3>Ошибка</h3>
    </div>
    <div class="modal-body">
        <p>Минимальная длина пароля 5-ть символов!</p>
    </div>
</div>