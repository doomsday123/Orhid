<?php
$query = mysql_query("SELECT  `id`,`name`, `tel`, `date` FROM `sewing`");
$array = mysql_fetch_array($query);

while($array)
{
    echo('<div class="img-rounded userList" id='.$array["id"].'>');
    echo($array["name"]);
    echo(" тел:".$array["tel"]);
    echo(" до ".$array["date"]);
    echo('</div>');
    $array = mysql_fetch_array($query);
}
?>

<script>
    $(".userList").click(function (){
        window.location.href = "/?page=selectSewing&id="+this.id;
    });
</script>


