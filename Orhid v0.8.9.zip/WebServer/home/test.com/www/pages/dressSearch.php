<?php
    if(isset($_GET["sn"]))
    {
        $sn = $_GET["sn"];
        $q = mysql_return("SELECT `id` FROM `dress` WHERE `sn` = '$sn'");
        if($q)
        {
            echo ('<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/?page=selectDress&id='.$q["id"].'">');
        }
        else
        {
            $class = "error";
        }
    }
?>

<div class="img-rounded content">
    <div class="row">
        <div class="control-group<?=" ".$class?>" style="text-align: center">Поиск: <input autofocus class="search" style="margin-top: 5px" placeholder="Серийный номер" type="text"></div>
    </div>
</div>

<script>
    $(document).keydown(function (key) {
        if($(".search").val().length > 0)
        if(key.which == 13)
            $("body").html('<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/?page=searchDress&sn='+$(".search").val()+'">');
    });
</script>