<?
session_start();
include ('function/function.php');
include ("class/classes.php");

connectDataBase('orchid');

if(isset($_POST["login"]))
{
    $modal = '';
    $redirect = '';
    if(!User::login($_POST["login"],$_POST["password"]))
        $modal = "$('#modal').modal();";
    else
        $redirect = '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/?page=main">';
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <?=$redirect?>
    <title>Авторизация</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery-2.0.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            $(".btn").click(function() {
                $("#form").submit();
            });
            $(document).keydown(function (key) {
                if(key.which == 13)
                    $("#form").submit();
            });
            <?=$modal?>
        });
    </script>
</head>
<body>

<div class="container" style="margin-top: 20px">
    <div class="navbar">
        <nav class="navbar-inner">
            <a class="brand">Авторизация</a>
            <ul class="nav">
                <li class="divider-vertical"></li>
            </ul>
            <div>
                <form id="form" method="POST" action="login.php" class="navbar-form pull-right">
                   <input id="login" type="text" name="login" placeholder="Логин" class="input-small">
                   <input type="password" name="password" placeholder="Пароль" class="input-small">
                   <a class="btn"><i class="icon-ok"></i></a>
                </form>
            </div>

        </nav>
    </div>
</div>
<div id="modal" class="modal hide fade">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3>Ошибка</h3>
    </div>
    <div class="modal-body">
        <p>Неправильный логин или пароль. Попробуйте снова, если не получится обратитесь к системному администратору!</p>
    </div>
</div>
</body>
</html>