<?PHP
include ('function/function.php');
include ('class/classes.php');
connectDataBase('orchid');
include ('function/checkLogin.php')

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Главная</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/ico">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <script src="js/jquery-2.0.3.min.js"></script>
    <script src="js/jquery.scrollUp.js"></script>
    <script>
        $(document).ready(function() {
            $("#logout").click(function() {
                document.cookie = "PHPSESSID=; expires=Thu, 01 Jan 1970 00:00:01 GMT";
                location.reload();
            });
        });
    </script>
</head>
<body>

    <div class="container" style="margin-top: 20px;">
        <div class="navbar">
            <nav class="navbar-inner">
                <a class="brand"><?=$user->getName()?></a>
                <ul class="nav">
                    <li class="divider-vertical"></li>
                    <li><a href="/?page=main">Главная</a></li>
                    <?
                    switch($user->getAccess())
                    {
                        case "Admin":
                           include("html/menuAdmin.html");
                        break;
                        case "User":
                            include("html/menuUser.html");
                        break;
                        case "Boss":
                            include("html/menuBoss.html");
                        break;
                    }
                    ?>
                </ul>
                <a id='logout' class="btn navbar-form pull-right"><i class="icon-off"></i></a>
            </nav>
        </div>

        <div class="hero-unit">
            <?
                switch($_GET["page"])
                {
                    case 'users':
                        include("pages/users.php");
                    break;
                    case 'newUsers':
                        include("pages/newUsers.php");
                    break;
                    case 'newDress':
                        include("pages/dressNewDress.php");
                    break;
                    case 'showDress':
                        include("pages/showDress.php");
                    break;
                    case 'selectDress':
                        include("pages/showDressSelect.php");
                    break;
                    case 'searchDress':
                        include("pages/dressSearch.php");
                    break;
                    case 'newSewing':
                        include("pages/sewingAdd.php");
                    break;
                    case 'showSewing':
                        include("pages/sewingShow.php");
                    break;
                    case 'selectSewing':
                        include("pages/sewingSelect.php");
                    break;
                }
            ?>
        </div>
    </div>

    <script src="js/bootstrap.min.js"></script>
    <script>$(function(){$.scrollUp()});</script>
</body>
</html>