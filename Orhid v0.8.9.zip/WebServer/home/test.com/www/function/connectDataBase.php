<?php
    function connectDataBase($name,$host = '127.0.0.1',$login = 'root',$password = '')
    {
        $ConnectDB = mysql_connect($host,$login,$password);
        mysql_selectdb($name,$ConnectDB);
        mysql_query("SET NAMES cp1251");
    }
?>