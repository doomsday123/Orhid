<?php
if(isset($_COOKIE['PHPSESSID']))
{
    $login = User::userExists($_COOKIE['PHPSESSID'],"ssid");
    if(strlen($login) < 1)
        exit('<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/login.php">');
    $user = new User($login);
}
else
    exit('<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=/login.php">');
?>