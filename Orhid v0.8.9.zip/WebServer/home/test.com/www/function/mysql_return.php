<?php
    function mysql_return($textQuery)
    {
        $query = mysql_query($textQuery);
        if($query == false)
            return false;
        return mysql_fetch_array($query);
    }
?>