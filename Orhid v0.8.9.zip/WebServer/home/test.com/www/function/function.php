<?php
    include('connectDataBase.php'); //Подключение к базе данных
    include('mysql_return.php'); //Вотвращает результат запроса в виде массива
?>